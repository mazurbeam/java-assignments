public class ListTester {
	public static void main(String[] args) {
		SLL myList = new SLL();
		myList.add(3);
		myList.add(2);
		myList.add(6);
		myList.add(3);
		myList.add(8);
		
		myList.printValues();
	}
}